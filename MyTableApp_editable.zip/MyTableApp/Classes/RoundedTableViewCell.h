//
//  RoundedTableViewCell.h
//
//  Created by Sabine Antritter on 13.04.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
/** add this **/
#import <QuartzCore/QuartzCore.h>



@interface RoundedTableViewCell : UITableViewCell {
	
	UILabel *label;
	
	/** add this **/
	CALayer* topleft;
	CALayer* topright;
	CALayer* bottomleft;
	CALayer* bottomright;
	CALayer* bglayer;
	BOOL roundTop;
	BOOL roundBottom;
}
@property (nonatomic, retain) UILabel *label;

/** add this **/
@property (nonatomic, retain) CALayer* topleft;
@property (nonatomic, retain) CALayer* topright;
@property (nonatomic, retain) CALayer* bottomleft;
@property (nonatomic, retain) CALayer* bottomright;
@property (nonatomic, retain) CALayer* bglayer;
@property (nonatomic) BOOL roundTop;
@property (nonatomic) BOOL roundBottom;

/** add this **/
-(void) drawRoundTop;
-(void) drawRoundBottom;

@end
