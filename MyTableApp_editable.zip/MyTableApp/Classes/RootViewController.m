//
//  RootViewController.m
//  MyTableApp
//
//  Created by Sabine Antritter on 13.04.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RootViewController.h"
#import "RoundedTableViewCell.h"
#import "NormalTableViewCell.h"
#import "MyTableAppAppDelegate.h"

@implementation RootViewController

#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {

	
	self.tableView.editing = YES;
	self.tableView.allowsSelectionDuringEditing = YES;
	
	// important!
	[self.tableView setBackgroundView:[[[UIView alloc] init] autorelease]];
	// background color plain style
	[self.tableView setBackgroundColor:[UIColor colorWithRed:0.69 green:0.81 blue:0.79 alpha:1.0]];
	self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
	[self.tableView setSeparatorColor:[UIColor clearColor]];
	
	[super viewDidLoad];
	
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
}
*/

/*
 // Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	// Return YES for supported orientations.
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
 */

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	MyTableAppAppDelegate *appdelegate = (MyTableAppAppDelegate *)[[UIApplication sharedApplication] delegate];
    
	if (indexPath.section == SECTION_NORMAL) {
		
		static NSString *CellIdentifier = @"Cell";
		
		NormalTableViewCell *cell = (NormalTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[NormalTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		}
		cell.label.text = [appdelegate.normalCellsArray objectAtIndex:indexPath.row];
		return cell;
		
	} else if (indexPath.section == SECTION_ROUNDED) {
		
		static NSString *CellRoundedIdentifier = @"RoundedTableViewCell";
		
		
		RoundedTableViewCell *cell = (RoundedTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellRoundedIdentifier];
		if (cell == nil) {
			cell = [[[RoundedTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellRoundedIdentifier] autorelease];
		}
		
		// Configure the cell.
		[cell.label setText:[appdelegate.normalCellsArray objectAtIndex:indexPath.row]];
		
		// draw round top corners in first row 
		if(indexPath.row == 0){
			[cell drawRoundTop];
		}
		
		if (indexPath.row == [self.tableView  numberOfRowsInSection:indexPath.section]-1) {
			[cell drawRoundBottom];
		}
		/*
		else {
			[cell drawFilled];
		}
		 */
		
	    cell.showsReorderControl = YES;
		
		return cell;
	} else {
		return nil;
	}
	
}

/*
- (UITableViewCellEditingStyle)tableView:(UITableView *)aTableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
	//return UITableViewCellEditingStyleNone;
}
*/

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	// Return the number of sections.
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView  numberOfRowsInSection:(NSInteger)section {
	NSInteger rows = 0;
    MyTableAppAppDelegate *appdelegate = (MyTableAppAppDelegate *)[[UIApplication sharedApplication] delegate];
    switch (section) {
		case SECTION_NORMAL:
			rows = [appdelegate.normalCellsArray count];
			break;
		case SECTION_ROUNDED:
			rows = [appdelegate.roundCellsArray count];
			break;
	}
	return rows;
	
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
	
	UIView* header = nil;
	if(section == SECTION_ROUNDED){
		CGRect rect = CGRectMake(0, 0, self.tableView.frame.size.width, [self tableView:(tableView) heightForHeaderInSection:section]);
		header = [[UIView alloc] initWithFrame:rect];
		
	}
	return header;
}

- (CGFloat) tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
	CGFloat h = 0;
	if(section == SECTION_ROUNDED){
		h = 15;
	}
	return h;
}
-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	CGFloat h = 44;
	if(indexPath.section == SECTION_ROUNDED){
		h = 60;
	}
	return h;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/



// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source.
		NSLog(@"delete %d",indexPath.row);
		MyTableAppAppDelegate *appdelegate = (MyTableAppAppDelegate *)[[UIApplication sharedApplication] delegate];
		switch (indexPath.section) {
			case SECTION_NORMAL:
				[appdelegate.normalCellsArray removeObjectAtIndex:indexPath.row];
				break;
			case SECTION_ROUNDED:
				[appdelegate.roundCellsArray removeObjectAtIndex:indexPath.row];
				break;
		}		
		[tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationNone];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
	[tableView reloadData];
}



/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
	/*
	 <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
	 [self.navigationController pushViewController:detailViewController animated:YES];
	 [detailViewController release];
	 */
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end

