//
//  RootViewController.h
//  MyTableApp
//
//  Created by Sabine Antritter on 13.04.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
	SECTION_NORMAL,
	SECTION_ROUNDED
} SectionType;

@interface RootViewController : UITableViewController {

}



@end
