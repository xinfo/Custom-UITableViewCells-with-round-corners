//
//  NormalTableViewCellCell.m
//  MyTableApp
//
//  Created by Sabine Antritter on 13.04.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "NormalTableViewCell.h"


@implementation NormalTableViewCell

@synthesize label;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code.
		label = [[UILabel alloc] initWithFrame:CGRectMake(self.contentView.frame.origin.x + 10,self.contentView.frame.origin.y,self.contentView.frame.size.width, self.contentView.frame.size.height)];
		label.textAlignment = UITextAlignmentLeft;
		label.backgroundColor = [UIColor clearColor];
		label.textColor = [UIColor whiteColor];		
		[self.contentView addSubview:label];
		
		
		/** remove this to have plain cells **/
		self.contentView.backgroundColor = [UIColor colorWithRed:0.33 green:0.59 blue:0.55 alpha:1.0];
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
}


- (void)dealloc {
	[label release];
	
    [super dealloc];
}



@end
