//
//  RoundedTableViewCell.m
//  TheElements
//
//  Created by Sabine Antritter on 13.04.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RoundedTableViewCell.h"

/** define the corner radius here **/
#define rad 15
/** define the cells background color **/
#define normalColor [UIColor colorWithRed:0.39 green:0.15 blue:0.24 alpha:1.0]
#define testColor [UIColor yellowColor]

@implementation RoundedTableViewCell

@synthesize label;
/** add this **/
@synthesize topleft;
@synthesize topright;
@synthesize bottomleft;
@synthesize bottomright;
@synthesize bglayer;
@synthesize roundTop;
@synthesize roundBottom;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
		label = [[UILabel alloc] initWithFrame:self.contentView.frame];
		label.textAlignment = UITextAlignmentLeft;
		label.backgroundColor = [UIColor clearColor];
		label.textColor = [UIColor whiteColor];	
		label.font = [UIFont fontWithName:@"Zapfino" size:16];
		[self.contentView addSubview:label];
		
		roundTop = NO;
		roundBottom = NO;
		
		self.layer.backgroundColor = normalColor.CGColor;
    }
	
    return self;
}


- (void) drawRect:(CGRect)rect{
	CGRect fr = rect;

	fr.size.width = fr.size.width-2*rad;
	fr.size.height = fr.size.height-1;
	fr.origin.x = rad;
	
	// draw round corners layer
	bglayer = [CALayer layer];
    bglayer.backgroundColor = normalColor.CGColor;
	bglayer.cornerRadius = rad;
	bglayer.frame = fr;
	bglayer.zPosition = -5;	// important, otherwise delete button does not fire / is covered
	[self.layer addSublayer:bglayer];

	 
	// set label size (adjust to heightForRowAtIndexPath..)
	label.frame = CGRectMake(rad, 5, fr.size.width, fr.size.height);
	
	// corner layer top left
	topleft = [CALayer layer];
    topleft.backgroundColor = normalColor.CGColor;
	CGRect tl = CGRectMake(rad, 0, rad, rad);
	topleft.frame = tl;
	topleft.zPosition = -4;
	if(roundTop){
		topleft.hidden = YES;
	}else {
		topleft.hidden = NO;
	}
    [self.layer addSublayer:topleft];
	
	// corner layer top right
	topright = [CALayer layer];
    topright.backgroundColor = normalColor.CGColor;
	topright.frame = CGRectMake(fr.size.width, 0, rad, rad);
	topright.zPosition = -3;
	if(roundTop){
		topright.hidden = YES;
	}
	else {
		topright.hidden = NO;
	}
    [self.layer addSublayer:topright];
	
	// corner layer bottom left
	bottomleft = [CALayer layer];
    bottomleft.backgroundColor = normalColor.CGColor;
	bottomleft.frame = CGRectMake(rad, fr.size.height-rad, rad, rad);
	bottomleft.zPosition = -2;
	if(roundBottom){
		bottomleft.hidden = YES;
	}else {
		bottomleft.hidden = NO;
	}
    [self.layer addSublayer:bottomleft];
	
	// corner layer bottom right
	bottomright = [CALayer layer];
	bottomright.backgroundColor = normalColor.CGColor;
	bottomright.frame = CGRectMake(fr.size.width, fr.size.height-rad, rad, rad);
	bottomright.zPosition = -1;
	if(roundBottom){
		bottomright.hidden = YES;
	}else {
		bottomright.hidden = NO;
	}
    [self.layer addSublayer:bottomright];
	
	[super drawRect:rect];
	
}

-(void) drawRoundTop{
	roundTop = YES;
	topleft.hidden = YES;
	topright.hidden = YES;
	
}
-(void) drawRoundBottom{
	roundBottom = YES;
	bottomleft.hidden = YES;
	bottomright.hidden = YES;
}

- (void)dealloc {
	[label release];
	
    [super dealloc];
}



@end












































